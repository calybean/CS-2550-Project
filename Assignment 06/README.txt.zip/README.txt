website url: http://youravgjoe.com/Assignment%2006/index.html

github repo: https://github.com/youravgjoe/CS-2550-Project/tree/master/Assignment%2006

Joseph Cannon
4/6/15
CS 2550

The info that is read in from the xml file is the gameString, which is the part of the model that the javascript uses to draw the board, and put the pieces in the correct place. I've also read in each player's number of plain checkers and star checkers. 
