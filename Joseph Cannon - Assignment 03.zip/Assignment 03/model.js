'use strict';

var CheckersModel = (function() {
  function GameModel() {
    this.rows = 8;
    this.columns = 8;
  };

  CheckersModel.prototype.generateTable = function() {
      this.board = new Array();
      for (var i = 0; i < this.rows; i++) {
        this.board[i] = new Array();
        for (var j = 0; j < this.columns; j++) {
          if(i + j % 2 === 0) {
            this.board[i][j] = 'red';
          } else {
            this.board[i][j] = 'black';
          }
        }
      }
  }
  return CheckersModel;
});
